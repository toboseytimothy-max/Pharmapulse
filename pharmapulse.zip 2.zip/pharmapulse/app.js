(()=>{'use strict';
/* ---------- constants ---------- */
const CATS={pv:['Pharmacovigilance','Pv','#a63d2f','01'],cr:['Clinical research','Cr','#4f6d5c','02'],ra:['Regulatory','Ra','#7a4e6a','03'],conf:['Conferences','Cf','#b07a1c','04'],gmp:['GMP & manufacturing','Gm','#5e6b3a','05'],radio:['Radiopharmacy','Rp','#c0623a','06'],hosp:['Hospital pharmacy','Hp','#3e6a80','07'],onc:['Oncology','On','#9b4b6e','08'],ph:['Public health','Ph','#2f6e63','09'],career:['Careers','Cv','#8a5a2b','10'],cpd:['CPD & training','Cd','#6b7f3a','11'],expo:['Exhibitions','Ex','#a07c2c','12'],webinar:['Webinars','Wb','#5b6f8a','13']};
const REGIONS=['Kenya','Africa','International','Online'];
const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const MONL=['January','February','March','April','May','June','July','August','September','October','November','December'];
const SOURCES=[['PPB CPD register (Kenya)','https://products.pharmacyboardkenya.org/ppb_admin/pages/public_view_cpd_events.php'],['PSK webinars','https://psk.or.ke/webinars/'],['Kenya Healthcare Federation calendar','https://khf.co.ke/2026-calendar-of-events/'],['Daktari Online events','https://confluence.daktarionline.co.ke/app.daktarionline.africa/public/index.php/events'],['RAPS regulatory events','https://www.raps.org/learn-develop/events.html'],['FIP international pharmacy','https://www.fip.org/events'],['ISoP pharmacovigilance','https://isoponline.org/training/seminar/isop-seminar-2026/'],['EMA events','https://www.ema.europa.eu/en/events/upcoming-events'],['PDA manufacturing events','https://www.pda.org/global-event-calendar'],['ISPE GMP training','https://my.ispe.org/ISPE/ispe/events/events_list.aspx'],['Parexel events','https://www.parexel.com/about-us/events'],['WHO events','https://www.who.int/news-room/events']];
/* ---------- hosts (logo plates) ---------- */
/* Brand-inspired wordmark plates. To show a real logo, drop the file in /logos and add it to LOGOS below,
   e.g. LOGOS.PDA='logos/pda.png'. A single event can also carry an "image" URL (poster/ad) in events.json. */
const LOGOS={};
const HOSTS=[[/^PDA/i,'PDA','Parenteral Drug Association','#0b3c6f'],[/^ISPE/i,'ISPE','International Society for Pharmaceutical Engineering','#00577c'],[/^RAPS/i,'RAPS','Regulatory Affairs Professionals Society','#1d4e89'],[/^WHO\b/i,'WHO','World Health Organization','#0093d5'],[/^Novartis/i,'NVS','Novartis','#0460a9'],[/^EMA/i,'EMA','European Medicines Agency','#003399'],[/^PSK/i,'PSK','Pharmaceutical Society of Kenya','#1f6f43'],[/^FIP/i,'FIP','International Pharmaceutical Federation','#00539b'],[/^Parexel/i,'PRX','Parexel','#0a8f8d'],[/^IDF/i,'IDF','International Diabetes Federation','#1769aa'],[/^International Cancer Institute/i,'ICI','International Cancer Institute','#7a1f5c'],[/^Daktari/i,'DO','Daktari Online','#2a7f62'],[/^Aga Khan/i,'AKU','Aga Khan University','#1b6b4a'],[/^Kenya Medical Association/i,'KMA','Kenya Medical Association','#8a1c1c'],[/^Ministry of Health/i,'MoH','Ministry of Health, Kenya','#a3231a'],[/^Africa CDC/i,'ACDC','Africa CDC','#2e7d32'],[/^Care Medical/i,'CMPA','Care Medical Professionals Association','#b33a3a'],[/^inSupply/i,'iS','inSupply Health','#d4571f'],[/^ISoP/i,'ISoP','International Society of Pharmacovigilance','#274472'],[/^UNAIDS/i,'UNAIDS','UNAIDS','#1e8fcf'],[/^UICC/i,'UICC','Union for International Cancer Control','#d9731a'],[/^DIA/i,'DIA','Drug Information Association','#b0202f']];
const orgName=e=>String(e.org||'').replace(/\s*\(PPB CPD\)/i,'').trim();
const isPPB=e=>/PPB CPD/i.test((e.org||'')+' '+(e.note||''));
function host(e){const o=orgName(e);for(const[r,c,f,col]of HOSTS)if(r.test(o))return{code:c,full:f,col};let h=0;for(const ch of o)h=(h*31+ch.charCodeAt(0))%360;const code=o.split(/[\s/]+/).filter(w=>/^[A-Za-z]/.test(w)).slice(0,2).map(w=>w[0]).join('').toUpperCase()||'?';return{code,full:o,col:`hsl(${h} 38% 32%)`}}
function hm(e,size){const h=host(e),lg=LOGOS[h.code];return`<span class="hm ${size||''} ${h.code.length>3?'w':''}" style="--hc:${h.col}">${lg?`<img src="${esc(lg)}" alt="" onerror="this.remove()">`:esc(h.code)}</span>`}
function poster(e){const h=host(e);return`<div class="poster" style="--hc:${h.col}">${e.image?`<img class="pimg" src="${esc(e.image)}" alt="" loading="lazy" onerror="this.remove()">`:''}<div class="pt">${hm(e,'l')}<div><b>${esc(h.full)}</b>${isPPB(e)?'<small>PPB-listed CPD</small>':'<small>Event host</small>'}</div></div></div>`}
const PPB_URL='https://pharmacyboardkenya.org/';
const PPB_CPD_URL='https://products.pharmacyboardkenya.org/ppb_admin/pages/public_view_cpd_events.php';
function ppbSheet(){openSheet(`<div class="ppbhead"><span class="hm l" style="--hc:#2f6e63">PPB</span><div><h2 style="margin:0">Pharmacy and Poisons Board</h2><p class="sub">Kenya's regulator for pharmacy practice, medicines and poisons</p></div></div>
<div class="why">Established under the Pharmacy and Poisons Act (Cap. 244), the Board regulates who may practise pharmacy and which premises, products and traders may handle drugs and poisons in Kenya.</div>
<div class="sec" style="margin-top:20px"><h2>What it does</h2></div>
<ul class="plain"><li>Registers and licenses pharmacists and pharmaceutical technologists</li><li>Licenses pharmacies, wholesalers, manufacturers and other premises</li><li>Registers medicines and health products before they are sold</li><li>Runs post-market surveillance and national pharmacovigilance</li><li>Oversees continuing professional development (CPD) for practitioners</li></ul>
<div class="sec" style="margin-top:20px"><h2>Why it matters here</h2></div>
<ul class="plain"><li>Events tagged <b>PPB CPD</b> are listed on the Board's CPD register. Check the points offered and how to claim them on the register.</li><li>Suspected adverse drug reactions and poor-quality products are reported to the Board.</li><li>Licence, CPD and registration rules change. Always confirm current requirements with the Board.</li></ul>
<div class="btnrow"><button class="btn" data-act="ppbEvents">Show PPB CPD events</button></div>
<div class="btnrow"><a class="btn ghost" href="${PPB_CPD_URL}" target="_blank" rel="noopener" style="text-decoration:none">CPD register ↗</a><a class="btn ghost" href="${PPB_URL}" target="_blank" rel="noopener" style="text-decoration:none">PPB website ↗</a></div>`)}
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ls={get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};

/* ---------- state ---------- */
const P=Object.assign({theme:'light',notifyNew:true,remind:true,leads:[1440],interests:[],regions:[],autoMins:30,feed:'',haptics:true,hidePast:true},ls.get('pp_prefs',{}));
const S={events:[],saved:new Set(ls.get('pp_saved',[])),notes:ls.get('pp_notes',{}),known:ls.get('pp_known',{}),newIds:ls.get('pp_new',{}),reminded:ls.get('pp_reminded',{}),log:ls.get('pp_log',[]),last:ls.get('pp_last',0),tab:'home',alertsSeen:ls.get('pp_aseen',0),bannerOff:ls.get('pp_banner',false)};
const F={ppb:false,q:'',cats:new Set(),region:'',format:'',status:'',month:'',past:false,sort:'date',mode:'list',cal:new Date(),calSel:null};
const saveP=()=>ls.set('pp_prefs',P),saveS=()=>{ls.set('pp_saved',[...S.saved]);ls.set('pp_notes',S.notes);ls.set('pp_new',S.newIds);ls.set('pp_reminded',S.reminded);ls.set('pp_log',S.log.slice(0,40))};

/* ---------- dates ---------- */
const pd=iso=>{if(!iso)return null;const[y,m,d]=iso.split('-').map(Number);return new Date(y,m-1,d)};
const startDT=e=>{const d=pd(e.start);return d&&new Date(d.getTime()+8*36e5)};
const endDT=e=>{const d=pd(e.end||e.start);return d&&new Date(d.getTime()+864e5-1)};
const now=()=>new Date();
function phase(e){if(!e.start)return'tbc';const n=now();if(n<startDT(e))return'upcoming';if(n<=endDT(e))return'now';return'past'}
function fmtRange(e){if(!e.start)return e.note||'Date to be confirmed';const a=pd(e.start),b=pd(e.end||e.start);const f=(d,y)=>`${d.getDate()} ${MON[d.getMonth()]}${y?' '+d.getFullYear():''}`;if(+a===+b)return f(a,1);if(a.getMonth()===b.getMonth()&&a.getFullYear()===b.getFullYear())return`${a.getDate()}–${b.getDate()} ${MON[a.getMonth()]} ${a.getFullYear()}`;return`${f(a,a.getFullYear()!==b.getFullYear())} – ${f(b,1)}`}
function rel(e){const p=phase(e);if(p==='tbc')return'Date to confirm';if(p==='now')return'Happening now';if(p==='past')return'Ended';const days=Math.ceil((startDT(e)-now())/864e5);if(days<=0)return'Today';if(days===1)return'Tomorrow';if(days<14)return`In ${days} days`;if(days<60)return`In ${Math.round(days/7)} weeks`;return`In ${Math.round(days/30)} months`}
const sig=e=>[e.title,e.start,e.end,e.status,e.location].join('|');
const evById=id=>S.events.find(e=>e.id===id);

/* ---------- theme ---------- */
function applyTheme(){let t=P.theme;if(t==='auto')t=matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';document.documentElement.dataset.theme=t;$('#themeColor').content=t==='light'?'#f1e5cf':'#1d120b'}
matchMedia('(prefers-color-scheme: light)').addEventListener?.('change',()=>P.theme==='auto'&&applyTheme());

/* ---------- ui helpers ---------- */
let toastT;function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('show'),2600)}
const buzz=(n=12)=>{if(P.haptics&&navigator.vibrate)try{navigator.vibrate(n)}catch(e){}};
const catTags=(e,n=2)=>(e.cats||[]).slice(0,n).map(c=>CATS[c]?`<span class="tag" style="--c:${CATS[c][2]}"><i class="cdot"></i>${CATS[c][0]}</span>`:'').join('');
function statusTag(e){const p=phase(e);if(S.newIds[e.id]&&p!=='past')return'<span class="tag new">NEW</span>';if(p==='now')return'<span class="tag now"><i class="live"></i>Live now</span>';if(p==='past')return'<span class="tag ended">Ended</span>';if(e.status==='tbc'||!e.start)return'<span class="tag st-tbc">Date TBC</span>';if(e.status==='rescheduled')return'<span class="tag st-rescheduled">Rescheduled</span>';if(e.status==='observance')return'<span class="tag st-observance">Awareness day</span>';return'<span class="tag st-confirmed">Confirmed</span>'}
const fmtTag=e=>e.format?`<span class="tag" style="--c:#7b6551">${esc(e.format)}</span>`:'';
function card(e){const a=pd(e.start);const sv=S.saved.has(e.id);
 return`<div class="card" data-act="open" data-id="${esc(e.id)}" role="button" tabindex="0"><div class="date ${a?'':'tbc'}">${a?`<b>${a.getDate()}</b><small>${MON[a.getMonth()]}</small>`:'<b>TBC</b>'}</div><div class="body"><h3>${esc(e.title)}</h3><p class="m">${hm(e,'s')}<span>${esc(orgName(e))} · ${esc(e.location||e.region)}</span></p><div class="tags">${statusTag(e)}${isPPB(e)?'<span class="tag" style="--c:#2f6e63">PPB CPD</span>':''}${fmtTag(e)}${catTags(e,1)}</div></div><button class="save ${sv?'on':''}" data-act="save" data-id="${esc(e.id)}" aria-label="${sv?'Unsave':'Save'} event"><svg viewBox="0 0 24 24"><path d="M6 3h12v18l-6-4-6 4z"/></svg></button></div>`}
const upcoming=()=>S.events.filter(e=>phase(e)!=='past');
const byStart=(a,b)=>(a.start||'9999')<(b.start||'9999')?-1:1;
const interestMatch=e=>(!P.interests.length||(e.cats||[]).some(c=>P.interests.includes(c)))&&(!P.regions.length||P.regions.includes(e.region));

/* ---------- views ---------- */
function showTab(t){S.tab=t;$$('.view').forEach(v=>v.hidden=v.id!=='view-'+t);$$('.tab').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));window.scrollTo(0,0);if(t==='alerts'){S.alertsSeen=Date.now();ls.set('pp_aseen',S.alertsSeen)}render();badges()}
function render(){({home:rHome,explore:rExplore,saved:rSaved,alerts:rAlerts})[S.tab]()}
function badges(){const n=S.saved.size;$('#savedBadge').hidden=!n;$('#savedBadge').textContent=n;const nn=Object.keys(S.newIds).length;$('#alertBadge').hidden=!nn||S.tab==='alerts';$('#alertBadge').textContent=nn;$('#bellDot').hidden=!nn}

function rHome(){
 const el=$('#view-home');if(!S.events.length){el.innerHTML='<div class="skel"></div><div class="skel"></div><div class="skel"></div>';return}
 const up=upcoming().filter(e=>e.start).sort(byStart);
 const sv=up.filter(e=>S.saved.has(e.id)),pr=up.filter(e=>e.priority&&e.status!=='observance'&&phase(e)==='upcoming'),ot=up.filter(e=>e.status!=='observance'&&phase(e)==='upcoming');
 const next=(sv.length?sv:pr.length?pr:ot.length?ot:up)[0]; const hour=now().getHours();const greet=hour<12?'Good morning':hour<17?'Good afternoon':'Good evening';
 const wk=up.filter(e=>(startDT(e)-now())<7*864e5&&e.status!=='observance');
 const tops=S.events.filter(e=>e.priority&&phase(e)!=='past').sort((a,b)=>a.priority-b.priority);
  const fresh=S.events.filter(e=>S.newIds[e.id]&&phase(e)!=='past');
 el.innerHTML=`
 <h2 class="greet">${greet},<em>here's the pulse.</em></h2>
 ${next?`<div class="hero"><div class="eyebrow">${S.saved.has(next.id)?'Your next saved event':'Next up'}</div><h3>${esc(next.title)}</h3><div class="meta">${fmtRange(next)} · ${esc(next.location||next.region)}</div><div class="hostln hh">${hm(next,'s')}${esc(orgName(next))}</div><div class="cd" id="cd" data-t="${startDT(next).getTime()}" data-e="${endDT(next).getTime()}"></div><button class="go" data-act="open" data-id="${esc(next.id)}">View details →</button></div>`:''}
 <div class="stats"><div class="stat"><b>${up.length}</b><span>Upcoming</span></div><div class="stat"><b>${wk.length}</b><span>This week</span></div><div class="stat"><b>${up.filter(e=>e.format==='Online'||e.region==='Online').length}</b><span>Online</span></div><div class="stat"><b>${S.saved.size}</b><span>Saved</span></div></div>
 ${fresh.length?`<div class="sec"><h2>New for you</h2><button data-act="clearNew">Mark seen</button></div>${fresh.slice(0,5).map(card).join('')}`:''}
 ${tops.length?`<div class="sec"><h2>Top picks for you</h2></div><div class="hscroll">${tops.slice(0,10).map((e,i)=>`<button class="pick" data-act="open" data-id="${esc(e.id)}"><span class="rank">${i+1}</span><div class="tags">${statusTag(e)}${catTags(e,1)}</div><h3>${esc(e.title)}</h3><p class="m">${fmtRange(e)}<br>${esc(e.location||e.region)}</p><span class="hostln">${hm(e,'s')}${esc(orgName(e))}</span></button>`).join('')}</div>`:''}
 <div class="sec"><h2>This week</h2><button data-act="goExplore">See all</button></div>
 ${wk.length?wk.slice(0,6).map(card).join(''):'<p class="sub">Nothing in the next 7 days. Check Explore for what\'s ahead.</p>'}
 <div class="sec"><h2>Pharmacy and Poisons Board</h2></div>
 <button class="ppbcard" data-act="ppb"><span class="hm l" style="--hc:#2f6e63">PPB</span><span class="pc"><b>PPB and CPD, at a glance</b><small>Who they are, what they regulate and how CPD events fit in. ${upcoming().filter(isPPB).length} upcoming PPB CPD event${upcoming().filter(isPPB).length===1?'':'s'}.</small></span><span class="chev">›</span></button>
 <p class="fine" style="text-align:center;margin:24px 0 6px">Dates come from official calendars checked ${esc(S.meta?.generated||'3 Nov 2026')}. Always confirm with the organiser.</p>`;
 tickCd();
}
function tickCd(){const c=$('#cd');if(!c)return;const t=+c.dataset.t,en=+c.dataset.e,n=Date.now();if(n>=t&&n<=en){c.innerHTML='<div style="min-width:120px"><b style="font-size:26px;font-style:italic">Live now</b><small>in progress</small></div>';return}let s=Math.max(0,Math.floor((t-n)/1000));const d=Math.floor(s/86400);s%=86400;const h=Math.floor(s/3600);s%=3600;const m=Math.floor(s/60);s%=60;c.innerHTML=[[d,'days'],[h,'hrs'],[m,'min'],[s,'sec']].map(([v,l])=>`<div><b>${String(v).padStart(2,'0')}</b><small>${l}</small></div>`).join('')}
setInterval(tickCd,1000);

function filtered(){const q=F.q.trim().toLowerCase();let r=S.events.filter(e=>{const p=phase(e);if(!F.past&&P.hidePast&&p==='past')return false;if(F.cats.size&&!(e.cats||[]).some(c=>F.cats.has(c)))return false;if(F.ppb&&!isPPB(e))return false;if(F.region&&e.region!==F.region)return false;if(F.format&&e.format!==F.format&&!(F.format==='Online'&&e.region==='Online'))return false;if(F.status&&(F.status==='tbc'?!(e.status==='tbc'||e.status==='rescheduled'||!e.start):e.status!==F.status))return false;if(F.month&&!(e.start&&e.start.slice(0,7)===F.month))return false;if(q&&![e.title,e.org,e.location,e.why,e.region,(e.cats||[]).map(c=>CATS[c]?.[0]).join(' ')].join(' ').toLowerCase().includes(q))return false;return true});
 if(F.sort==='date')r.sort(byStart);else if(F.sort==='priority')r.sort((a,b)=>(a.priority||99)-(b.priority||99)||byStart(a,b));else r.sort((a,b)=>a.title.localeCompare(b.title));return r}
function rExplore(){const el=$('#view-explore');
 const act=[F.region,F.format,F.status,F.month,F.past?'p':'',F.ppb?'b':''].filter(Boolean).length;
 if(!el.querySelector('#xres')){el.innerHTML=`<div class="search"><label><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><input id="q" type="search" placeholder="Search events, orgs, topics…" autocomplete="off"></label><button class="icon-btn" id="fbtn" style="width:46px;height:46px" aria-label="Filters"><svg viewBox="0 0 24 24"><path d="M4 6h16M7 12h10M10 18h4"/></svg><i class="dot" id="fdot" hidden></i></button></div>
 <div class="chips" id="xchips"></div><div class="seg" style="margin-bottom:10px"><button data-act="mode" data-m="list">List</button><button data-act="mode" data-m="cal">Calendar</button></div><div id="xres"></div>`;
 const q=$('#q');q.value=F.q;q.addEventListener('input',()=>{F.q=q.value;xres()});$('#fbtn').onclick=filterSheet}
 $('#fdot').hidden=!act;
 $('#xchips').innerHTML=`<button class="chip ${F.cats.size?'':'on'}" data-act="cat" data-cat="">All</button>`+Object.entries(CATS).map(([k,v])=>`<button class="chip ${F.cats.has(k)?'on':''}" data-act="cat" data-cat="${k}"><i class="cdot" style="--c:${v[2]}"></i>${v[0]}</button>`).join('');
 $$('#view-explore .seg button').forEach(b=>b.classList.toggle('on',b.dataset.m===F.mode));xres()}
function xres(){const el=$('#xres');if(!el)return;const r=filtered();
 if(F.mode==='cal'){el.innerHTML=calHtml(r);return}
 if(!r.length){el.innerHTML='<div class="empty"><div class="orn">?</div><h3>No events match</h3><p>Try clearing a filter or searching something broader.</p><div class="btnrow" style="justify-content:center"><button class="btn ghost" data-act="clearF">Clear filters</button></div></div>';return}
 let h=`<p class="sub" style="margin:2px 2px 8px">${r.length} event${r.length>1?'s':''}</p>`,last='';
 r.forEach(e=>{const k=F.sort==='date'?(e.start?MONL[pd(e.start).getMonth()]+' '+pd(e.start).getFullYear():'Date to confirm'):'';if(k&&k!==last){h+=`<div class="mhead">${k}</div>`;last=k}h+=card(e)});el.innerHTML=h}
function calHtml(r){const y=F.cal.getFullYear(),m=F.cal.getMonth(),first=new Date(y,m,1),pad=(first.getDay()+6)%7,dim=new Date(y,m+1,0).getDate(),td=now();
 const on=d=>r.filter(e=>e.start&&pd(e.start)<=d&&pd(e.end||e.start)>=d);let cells='';
 ['M','T','W','T','F','S','S'].forEach(x=>cells+=`<div class="dow">${x}</div>`);
 for(let i=0;i<pad;i++)cells+='<div class="day out"></div>';
 for(let d=1;d<=dim;d++){const dt=new Date(y,m,d),ev=on(dt),isT=dt.toDateString()===td.toDateString(),sel=F.calSel&&+F.calSel===+dt;const cols=[...new Set(ev.map(e=>CATS[e.cats?.[0]]?.[2]||'#22d3aa'))].slice(0,3);cells+=`<button class="day ${isT?'today':''} ${sel?'sel':''}" data-act="day" data-d="${+dt}">${d}<span class="pips">${cols.map(c=>`<i style="--c:${c}"></i>`).join('')}</span></button>`}
 const list=F.calSel?on(F.calSel):r.filter(e=>e.start&&pd(e.start).getMonth()===m&&pd(e.start).getFullYear()===y).sort(byStart);
 return`<div class="cal"><div class="cal-h"><button data-act="cm" data-n="-1" aria-label="Previous month">‹</button><b>${MONL[m]} ${y}</b><button data-act="cm" data-n="1" aria-label="Next month">›</button></div><div class="grid7">${cells}</div></div><div class="sec" style="margin-top:6px"><h2>${F.calSel?F.calSel.getDate()+' '+MONL[m]:'Starting this month'}</h2>${F.calSel?'<button data-act="day" data-d="">Show month</button>':''}</div>${list.length?list.map(card).join(''):'<p class="sub">No events.</p>'}`}
function filterSheet(){const months=[...new Set(S.events.filter(e=>e.start).map(e=>e.start.slice(0,7)))].sort();
 const sel=(id,opts,val)=>`<select id="${id}">${opts.map(([v,l])=>`<option value="${v}" ${v===val?'selected':''}>${l}</option>`).join('')}</select>`;
 openSheet(`<h2>Filters</h2><div class="panel" style="padding:12px 14px"><p class="sub">Region</p>${sel('fr',[['','Anywhere'],...REGIONS.map(r=>[r,r])],F.region)}<p class="sub" style="margin-top:10px">Format</p>${sel('ff',[['','Any'],['In-person','In-person'],['Online','Online'],['Hybrid','Hybrid']],F.format)}<p class="sub" style="margin-top:10px">Status</p>${sel('fs',[['','Any'],['confirmed','Confirmed'],['tbc','Date to confirm / rescheduled'],['observance','Awareness days']],F.status)}<p class="sub" style="margin-top:10px">Month</p>${sel('fm',[['','Any month'],...months.map(m=>[m,MONL[+m.slice(5)-1]+' '+m.slice(0,4)])],F.month)}<p class="sub" style="margin-top:10px">Sort by</p>${sel('fo',[['date','Date'],['priority','My priority ranking'],['name','Name A–Z']],F.sort)}<div class="row"><div class="l"><b>PPB CPD events only</b></div><button class="sw ${F.ppb?'on':''}" id="fb" aria-label="PPB CPD only"></button></div><div class="row"><div class="l"><b>Include past events</b></div><button class="sw ${F.past?'on':''}" id="fp" aria-label="Include past"></button></div></div><div class="btnrow"><button class="btn ghost" data-act="clearF">Reset</button><button class="btn" id="fapply">Show results</button></div>`);
 $('#fp').onclick=e=>e.currentTarget.classList.toggle('on');$('#fb').onclick=e=>e.currentTarget.classList.toggle('on');
 $('#fapply').onclick=()=>{F.region=$('#fr').value;F.format=$('#ff').value;F.status=$('#fs').value;F.month=$('#fm').value;F.sort=$('#fo').value;F.past=$('#fp').classList.contains('on');F.ppb=$('#fb').classList.contains('on');closeSheet();rExplore()}}
function rSaved(){const el=$('#view-saved');const r=S.events.filter(e=>S.saved.has(e.id)).sort(byStart);
 if(!r.length){el.innerHTML='<div class="empty"><div class="orn">Rx</div><h3>Nothing saved yet</h3><p>Tap the bookmark on any event to keep it here and get reminders.</p><div class="btnrow" style="justify-content:center"><button class="btn" data-act="goExplore">Explore events</button></div></div>';return}
 const up=r.filter(e=>phase(e)!=='past'),past=r.filter(e=>phase(e)==='past');
 el.innerHTML=`<div class="sec"><h2>Saved (${r.length})</h2><button data-act="exportAll">Add all to calendar</button></div>${up.map(e=>card(e)+(S.notes[e.id]?`<p class="fine" style="margin:-4px 8px 10px">Note: ${esc(S.notes[e.id])}</p>`:'')).join('')}${past.length?`<div class="sec"><h2>Past</h2></div>${past.map(card).join('')}`:''}`}
function rAlerts(){const el=$('#view-alerts');const perm='Notification' in window?Notification.permission:'unsupported';
 const sw=(k,on)=>`<button class="sw ${on?'on':''}" data-act="tog" data-k="${k}" aria-label="${k}"></button>`;
 const mins=[[0,'Manual only'],[15,'Every 15 min'],[30,'Every 30 min'],[60,'Every hour'],[180,'Every 3 hours']];
 el.innerHTML=`
 <div class="sec" style="margin-top:8px"><h2>Alerts &amp; sync</h2></div>
 <div class="callout"><h3>${perm==='granted'?'Notifications are on':perm==='denied'?'Notifications are blocked':'Turn on notifications'}</h3><p>${perm==='granted'?'You will be alerted when new events are added or updated, and before events you saved.':perm==='denied'?'Allow notifications for this app in Android Settings → Apps → PharmaPulse (or Chrome site settings).':'Get alerts for new events and reminders for saved ones.'}</p>${perm==='default'?'<div class="btnrow"><button class="btn" data-act="enableNotif">Enable notifications</button></div>':perm==='granted'?'<div class="btnrow"><button class="btn ghost" data-act="testNotif">Send a test</button></div>':''}</div>
 ${Object.keys(S.newIds).length?`<div class="panel"><div class="row"><div class="l"><b>${Object.keys(S.newIds).length} new/updated event${Object.keys(S.newIds).length>1?'s':''}</b><span>Highlighted with a NEW badge</span></div><button class="btn ghost" data-act="clearNew">Mark seen</button></div></div>`:''}
 <div class="panel"><div class="row"><div class="l"><b>New event alerts</b><span>When the feed adds or changes an event</span></div>${sw('notifyNew',P.notifyNew)}</div>
 <div class="row"><div class="l"><b>Reminders for saved events</b><span>Choose how early</span></div>${sw('remind',P.remind)}</div>
 <div class="row" style="display:block"><div class="chips" style="margin:0 -2px;padding:0 2px">${[[10080,'1 week'],[1440,'1 day'],[60,'1 hour']].map(([m,l])=>`<button class="chip ${P.leads.includes(m)?'on':''}" data-act="lead" data-m="${m}">${l} before</button>`).join('')}</div></div></div>
 <div class="sec"><h2>Only alert me about…</h2></div>
 <div class="panel" style="padding:12px 14px"><p class="sub" style="margin-bottom:8px">Areas (none selected = everything)</p><div class="tags" style="margin:0 0 12px">${Object.entries(CATS).map(([k,v])=>`<button class="chip ${P.interests.includes(k)?'on':''}" data-act="int" data-k="${k}"><i class="cdot" style="--c:${v[2]}"></i>${v[0]}</button>`).join('')}</div><p class="sub" style="margin-bottom:8px">Regions</p><div class="tags" style="margin:0">${REGIONS.map(r=>`<button class="chip ${P.regions.includes(r)?'on':''}" data-act="reg" data-k="${r}">${r}</button>`).join('')}</div></div>
 <div class="sec"><h2>Auto-refresh</h2></div>
 <div class="panel" style="padding:12px 14px"><p class="sub" style="margin-bottom:6px">While the app is open</p><select id="autoMins">${mins.map(([v,l])=>`<option value="${v}" ${v===P.autoMins?'selected':''}>${l}</option>`).join('')}</select><p class="sub" style="margin:12px 0 6px">Live feed URL (optional)</p><input type="url" id="feed" placeholder="https://your-site.com/events.json" value="${esc(P.feed)}"><p class="fine">Leave blank to use the built-in feed. Point this at a hosted events.json and every new event you publish appears here and triggers an alert.</p><div class="btnrow"><button class="btn" id="syncNow" data-act="sync">Refresh now</button></div><p class="fine">Last checked: ${S.last?new Date(S.last).toLocaleString():'never'}</p></div>
 ${S.log.length?`<div class="sec"><h2>Recent changes</h2></div><div class="panel"><ul class="log">${S.log.slice(0,12).map(l=>`<li>${esc(l.t)} <small>· ${new Date(l.at).toLocaleDateString()}</small></li>`).join('')}</ul></div>`:''}
 <div class="sec"><h2>Appearance</h2></div>
 <div class="panel" style="padding:12px 14px"><div class="seg">${[['light','Cream'],['dark','Espresso'],['auto','Auto']].map(([t,l])=>`<button data-act="theme" data-t="${t}" class="${P.theme===t?'on':''}">${l}</button>`).join('')}</div><div class="row"><div class="l"><b>Haptic feedback</b></div>${sw('haptics',P.haptics)}</div><div class="row"><div class="l"><b>Hide ended events on Explore</b></div>${sw('hidePast',P.hidePast)}</div></div>
 ${S.installEv?'<div class="callout"><h3>Install PharmaPulse</h3><p>Add it to your home screen for a full-screen, offline-ready app.</p><div class="btnrow"><button class="btn" data-act="install">Install app</button></div></div>':''}
 <div class="sec"><h2>Official calendars to bookmark</h2></div>
 <div class="panel">${SOURCES.map(([n,u])=>`<div class="row"><div class="l"><b style="font-weight:600">${esc(n)}</b></div><a href="${u}" target="_blank" rel="noopener">Open ↗</a></div>`).join('')}</div>
 <div class="sec"><h2>About</h2></div><div class="panel" style="padding:12px 14px"><p class="fine" style="margin:0">PharmaPulse v1.0 · ${S.events.length} events · feed ${esc(S.meta?.generated||'')}.<br>Undated items are flagged <b>Date TBC</b>, never guessed. Past events are not shown as upcoming. Reminders and background checks run when your phone allows PWAs to run in the background; opening the app always refreshes.</p><div class="btnrow"><button class="btn danger" data-act="reset">Reset app data</button></div></div>`;
 $('#autoMins').onchange=e=>{P.autoMins=+e.target.value;saveP();schedule()};
 $('#feed').onchange=e=>{P.feed=e.target.value.trim();saveP();toast('Feed saved');sync(true)}}

/* ---------- detail sheet ---------- */
let sheetOpen=false;
function openSheet(html){$('#sheetBody').innerHTML=html;$('#sheet').hidden=false;$('#scrim').hidden=false;$('#sheet').scrollTop=0;document.body.style.overflow='hidden';if(!sheetOpen){history.pushState({sheet:1},'');sheetOpen=true}}
function closeSheet(fromPop){$('#sheet').hidden=true;$('#scrim').hidden=true;document.body.style.overflow='';if(sheetOpen){sheetOpen=false;if(!fromPop&&history.state?.sheet)history.back()}}
window.addEventListener('popstate',()=>{if(sheetOpen)closeSheet(true)});
function detail(id){const e=evById(id);if(!e)return;const sv=S.saved.has(id);if(S.newIds[id]){delete S.newIds[id];saveS();badges()}
 openSheet(`${poster(e)}<div class="tags" style="margin-top:2px">${statusTag(e)}${e.priority?`<span class="tag" style="--c:#b07a1c">Top pick #${e.priority}</span>`:''}${fmtTag(e)}</div><h2>${esc(e.title)}</h2><p class="sub" style="font-size:13px">${esc(orgName(e))}</p><dl class="kv"><dt>When</dt><dd>${fmtRange(e)}<br><span style="color:var(--acc)">${rel(e)}</span></dd><dt>Where</dt><dd>${esc(e.location||'—')}</dd><dt>Region</dt><dd>${esc(e.region)}</dd>${e.fee?`<dt>Fee</dt><dd>${esc(e.fee)}</dd>`:''}<dt>Areas</dt><dd><span class="tags" style="margin:0">${catTags(e,4)}</span></dd></dl>${e.why?`<div class="why">${esc(e.why)}</div>`:''}${e.note?`<div class="why" style="margin-top:8px">${esc(e.note)}</div>`:''}${isPPB(e)?`<div class="ppbnote"><b>PPB CPD event</b><p>Check the CPD points and how to claim them on the Board's register.</p><div class="btnrow" style="margin-top:8px"><a class="btn ghost" href="${PPB_CPD_URL}" target="_blank" rel="noopener" style="text-decoration:none">CPD register ↗</a><button class="btn ghost" data-act="ppb">About PPB</button></div></div>`:''}
 ${sv?`<p class="sub" style="margin:14px 0 6px">My note</p><textarea id="note" placeholder="Registration deadline, who to ask, travel plans…">${esc(S.notes[id]||'')}</textarea>`:''}
 <div class="btnrow"><button class="btn ${sv?'ghost':'acc'}" data-act="save" data-id="${esc(id)}" data-sheet="1">${sv?'Saved':'Save'}</button>${e.start?`<button class="btn ghost" data-act="ics" data-id="${esc(id)}">Add to calendar</button>`:''}</div>
 <div class="btnrow"><button class="btn ghost" data-act="share" data-id="${esc(id)}">Share</button>${e.url?`<a class="btn" href="${esc(e.url)}" target="_blank" rel="noopener" style="text-decoration:none">Official page ↗</a>`:''}</div>
 <p class="fine">Dates are from the organiser's public listing. Please confirm registration, fees and CPD points on the official page before you commit.</p>`);
 const n=$('#note');if(n)n.oninput=()=>{S.notes[id]=n.value;saveS()}}

/* ---------- actions ---------- */
function toggleSave(id,fromSheet){if(S.saved.has(id)){S.saved.delete(id)}else{S.saved.add(id);toast('Saved · reminders on')}buzz();saveS();badges();if(fromSheet)detail(id);else render()}
function ics(list){const z=n=>String(n).padStart(2,'0'),dd=d=>`${d.getFullYear()}${z(d.getMonth()+1)}${z(d.getDate())}`,x=s=>String(s||'').replace(/\\/g,'\\\\').replace(/[,;]/g,m=>'\\'+m).replace(/\n/g,'\\n');
 const L=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//PharmaPulse//EN','CALSCALE:GREGORIAN'];
 list.filter(e=>e.start).forEach(e=>{const a=pd(e.start),b=new Date(pd(e.end||e.start).getTime()+864e5+36e5);L.push('BEGIN:VEVENT',`UID:${e.id}@pharmapulse`,`DTSTAMP:${new Date().toISOString().replace(/[-:]/g,'').split('.')[0]}Z`,`DTSTART;VALUE=DATE:${dd(a)}`,`DTEND;VALUE=DATE:${dd(new Date(pd(e.end||e.start).getTime()+864e5+36e5))}`,`SUMMARY:${x(e.title)}`,`LOCATION:${x(e.location)}`,`DESCRIPTION:${x((e.why||'')+(e.url?'\n'+e.url:''))}`,e.url?`URL:${e.url}`:'','BEGIN:VALARM','TRIGGER:-P1D','ACTION:DISPLAY','DESCRIPTION:Tomorrow: '+x(e.title),'END:VALARM','END:VEVENT')});
 L.push('END:VCALENDAR');const blob=new Blob([L.filter(Boolean).join('\r\n')],{type:'text/calendar'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=list.length===1?'pharmapulse-event.ics':'pharmapulse-saved.ics';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500);toast('Calendar file ready')}
async function share(id){const e=evById(id);const text=`${e.title}\n${fmtRange(e)} · ${e.location||e.region}\n${e.url||''}`;try{if(navigator.share)await navigator.share({title:e.title,text});else{await navigator.clipboard.writeText(text);toast('Copied to clipboard')}}catch(err){}}
async function askNotif(){if(!('Notification' in window)){toast('Notifications not supported here');return}const r=await Notification.requestPermission();if(r==='granted'){toast('Alerts enabled');notify('PharmaPulse alerts are on','You\'ll hear about new events and reminders here.','welcome');regBg()}S.bannerOff=true;ls.set('pp_banner',true);render()}
async function notify(title,body,tag,url){if(!('Notification' in window)||Notification.permission!=='granted')return false;try{const reg=await navigator.serviceWorker?.getRegistration();const o={body,icon:'icons/icon-192.png',badge:'icons/badge-96.png',tag,data:{url:url||'./'},vibrate:[80,40,80]};if(reg)await reg.showNotification(title,o);else new Notification(title,o);return true}catch(e){return false}}

/* ---------- sync ---------- */
function mirror(){try{caches.open('pp-meta').then(c=>c.put('/__pp_meta',new Response(JSON.stringify({known:S.known,saved:[...S.saved],reminded:S.reminded,feed:P.feed,notifyNew:P.notifyNew,remind:P.remind,leads:P.leads,interests:P.interests,regions:P.regions}))))}catch(e){}}
async function regBg(){try{const reg=await navigator.serviceWorker.ready;if('periodicSync' in reg)await reg.periodicSync.register('pp-sync',{minInterval:6*36e5})}catch(e){}}
let syncing=false;
async function sync(manual){if(syncing)return;syncing=true;$('#btnSync').classList.add('spin');
 try{const base=P.feed||'events.json';const r=await fetch(base+(base.includes('?')?'&':'?')+'_='+Date.now(),{cache:'no-store'});if(!r.ok)throw new Error(r.status);const j=await r.json();const list=(Array.isArray(j)?j:j.events||[]).filter(e=>e&&e.id&&e.title);if(!list.length)throw new Error('empty');
  S.meta=Array.isArray(j)?{}:{generated:j.generated};const first=!Object.keys(S.known).length;const added=[],changed=[];
  list.forEach(e=>{const s=sig(e);if(!(e.id in S.known)){if(!first)added.push(e)}else if(S.known[e.id]!==s)changed.push(e);S.known[e.id]=s});
  S.events=list;ls.set('pp_known',S.known);ls.set('pp_events',list);ls.set('pp_meta',S.meta);
  added.concat(changed).forEach(e=>S.newIds[e.id]=Date.now());
  added.forEach(e=>S.log.unshift({t:'Added: '+e.title,at:Date.now()}));changed.forEach(e=>S.log.unshift({t:'Updated: '+e.title,at:Date.now()}));
  const mine=added.filter(interestMatch),mineC=changed.filter(e=>S.saved.has(e.id)||interestMatch(e));
  if(P.notifyNew&&mine.length)await notify(mine.length===1?'New event: '+mine[0].title:`${mine.length} new events on PharmaPulse`,mine.length===1?`${fmtRange(mine[0])} · ${mine[0].location||mine[0].region}`:mine.slice(0,3).map(e=>e.title).join(' · '),'new-events');
  if(P.notifyNew&&mineC.length)await notify(mineC.length===1?'Event updated: '+mineC[0].title:`${mineC.length} events updated`,mineC.length===1?fmtRange(mineC[0]):mineC.slice(0,3).map(e=>e.title).join(' · '),'updated-events');
  S.last=Date.now();ls.set('pp_last',S.last);saveS();mirror();
  if(manual)toast(added.length||changed.length?`${added.length} new · ${changed.length} updated`:'You\'re up to date');
 }catch(err){if(manual)toast('Offline or feed unreachable — showing saved data');if(!S.events.length){const c=ls.get('pp_events',[]);S.events=c}}
 syncing=false;$('#btnSync').classList.remove('spin');line();checkReminders();badges();if(!sheetOpen)render()}
function line(){const m=S.last?Math.max(1,Math.round((Date.now()-S.last)/6e4)):0;$('#syncLine').textContent=S.events.length?`${upcoming().length} upcoming · ${S.last?(m<2?'synced just now':m<60?`synced ${m} min ago`:`synced ${Math.round(m/60)}h ago`):'not synced'}`:'Loading…'}
let timer;function schedule(){clearInterval(timer);if(P.autoMins>0)timer=setInterval(()=>sync(false),P.autoMins*6e4)}
function checkReminders(){if(!P.remind)return;const n=Date.now();S.saved.forEach(id=>{const e=evById(id);if(!e||!e.start)return;const t=startDT(e).getTime();P.leads.forEach(l=>{const k=id+'|'+l;if(n>=t-l*6e4&&n<t&&!S.reminded[k]){S.reminded[k]=n;saveS();notify(`${l>=10080?'In a week':l>=1440?'Tomorrow':'Starting soon'}: ${e.title}`,`${fmtRange(e)} · ${e.location||e.region}`,'rem-'+k,'./')}})});mirror()}
setInterval(()=>{checkReminders();line()},6e4);

/* ---------- events ---------- */
document.addEventListener('click',ev=>{const t=ev.target.closest('[data-act]');if(!t){if(ev.target.id==='scrim')closeSheet();return}const a=t.dataset.act,id=t.dataset.id;
 if(a==='save'){ev.stopPropagation();toggleSave(id,t.dataset.sheet)}
 else if(a==='open'){if(ev.target.closest('.save'))return;detail(id)}
 else if(a==='cat'){const c=t.dataset.cat;if(S.tab!=='explore'){F.cats.clear();if(c)F.cats.add(c);showTab('explore');return}if(!c)F.cats.clear();else F.cats.has(c)?F.cats.delete(c):F.cats.add(c);rExplore()}
 else if(a==='mode'){F.mode=t.dataset.m;F.calSel=null;rExplore()}
 else if(a==='cm'){F.cal=new Date(F.cal.getFullYear(),F.cal.getMonth()+ +t.dataset.n,1);F.calSel=null;xres()}
 else if(a==='day'){F.calSel=t.dataset.d?new Date(+t.dataset.d):null;xres()}
 else if(a==='clearF'){F.ppb=false;F.q='';F.cats.clear();F.region=F.format=F.status=F.month='';F.past=false;F.sort='date';F.calSel=null;closeSheet();$('#view-explore').innerHTML='';rExplore()}
 else if(a==='goExplore')showTab('explore');
 else if(a==='ppb')ppbSheet();
 else if(a==='ppbEvents'){closeSheet();F.ppb=true;F.mode='list';F.calSel=null;showTab('explore')}
 else if(a==='enableNotif')askNotif();
 else if(a==='testNotif')notify('PharmaPulse test','Alerts are working.','test').then(ok=>toast(ok?'Test sent':'Could not send'));
 else if(a==='dismissBanner'){S.bannerOff=true;ls.set('pp_banner',true);render()}
 else if(a==='clearNew'){S.newIds={};saveS();badges();render()}
 else if(a==='sync'){sync(true)}
 else if(a==='tog'){const k=t.dataset.k;P[k]=!P[k];saveP();mirror();render()}
 else if(a==='lead'){const m=+t.dataset.m;P.leads=P.leads.includes(m)?P.leads.filter(x=>x!==m):[...P.leads,m];if(!P.leads.length)P.leads=[1440];saveP();mirror();render()}
 else if(a==='int'||a==='reg'){const arr=a==='int'?P.interests:P.regions,k=t.dataset.k;const i=arr.indexOf(k);i<0?arr.push(k):arr.splice(i,1);saveP();mirror();render()}
 else if(a==='theme'){P.theme=t.dataset.t;saveP();applyTheme();render()}
 else if(a==='ics')ics([evById(id)]);
 else if(a==='exportAll')ics(S.events.filter(e=>S.saved.has(e.id)));
 else if(a==='share')share(id);
 else if(a==='install'){S.installEv?.prompt();S.installEv=null;render()}
 else if(a==='reset'){if(confirm('Clear saved events, notes and settings on this device?')){localStorage.clear();caches.delete('pp-meta');location.reload()}}
 buzz(8)});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches?.('.card[data-act=open]')){e.preventDefault();detail(e.target.dataset.id)}if(e.key==='Escape'&&sheetOpen)closeSheet()});
$$('.tab').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
$('#btnSync').onclick=()=>sync(true);$('#btnBell').onclick=()=>showTab('alerts');
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();S.installEv=e;if(S.tab==='alerts')render()});
window.addEventListener('appinstalled',()=>{S.installEv=null;toast('PharmaPulse installed')});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&Date.now()-S.last>3e5)sync(false)});
addEventListener('online',()=>sync(false));
/* pull to refresh */
let py=0,pull=false;addEventListener('touchstart',e=>{if(scrollY<=0&&!sheetOpen){py=e.touches[0].clientY;pull=true}},{passive:true});
addEventListener('touchmove',e=>{if(!pull)return;const d=e.touches[0].clientY-py;$('#ptr').classList.toggle('show',d>70);$('#ptr span').textContent=d>70?'Release to refresh':'Pull to refresh'},{passive:true});
addEventListener('touchend',()=>{if(!pull)return;pull=false;if($('#ptr').classList.contains('show')){$('#ptr').classList.remove('show');sync(true)}});

/* ---------- boot ---------- */
async function boot(){applyTheme();S.events=ls.get('pp_events',[]);S.meta=ls.get('pp_meta',{});if(S.events.length)render();
 if('serviceWorker' in navigator)try{await navigator.serviceWorker.register('sw.js');regBg()}catch(e){}
 const v=new URLSearchParams(location.search).get('view');if(['home','explore','saved','alerts'].includes(v))S.tab=v;
 await sync(false);showTab(S.tab);line();schedule()}
boot();
})();
