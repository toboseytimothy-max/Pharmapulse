# PharmaPulse

Design: cream / beige / dark-brown apothecary theme ("Cream" and "Espresso" modes in Alerts -> Appearance). Fonts (Lora + Poppins) are bundled in /fonts so they work offline.

Installable Android app (PWA) for pharma, pharmacy, PV, regulatory, GMP, clinical-research and public-health events. 146 entries from your research, with live sync, alerts, reminders, calendar export and offline use.

## Get it on your phone (5 minutes, free)
1. Host this folder over HTTPS: drag it onto https://app.netlify.com/drop, or push to GitHub and enable Pages.
2. Open the URL in Chrome on Android -> menu -> **Install app**. It installs with the PharmaPulse icon, full-screen, works offline.
3. Open the **Alerts** tab -> **Enable notifications**.

## Make a real APK (optional)
Go to https://www.pwabuilder.com, enter your hosted URL, choose Android, download the package. (Needed only for Play Store / sideloading.)

## How updates work
- On open, on return to the app, on reconnect, via pull-to-refresh, and every N minutes (Alerts -> Auto-refresh) the app re-fetches `events.json` (or your own Feed URL).
- Any new or changed event is flagged NEW, logged under Recent changes, and sent as a notification (filtered by your chosen areas/regions).
- Android Chrome can also run background checks for installed PWAs (Periodic Background Sync); timing is controlled by Android and not guaranteed.
- To publish new events: add an object to `events.json` on your host. Every installed copy picks it up. Fields: id, title, org, cats[], start, end (YYYY-MM-DD), region (Kenya/Africa/International/Online), format, location, status (confirmed/tbc/rescheduled/observance), url, why, priority.

## Limits to know
- A phone app cannot scrape other websites itself (browser security). New events appear when *your* events.json is updated. Fully automatic discovery needs a small server job that writes events.json.
- Instant push while the app is fully closed requires a push server; this build uses local notifications + background sync instead.
- Undated items are marked Date TBC. Always confirm details on the organiser's page.

## Host logos and posters
Events show a brand-coloured host plate (PDA, ISPE, WHO, PSK, PPB and others). To use a real logo, put the file in `logos/` and register it in `LOGOS` at the top of `app.js` (e.g. `LOGOS.PDA='logos/pda.png'`). To show a poster or ad for one event, add `"image": "https://..."` to that event in `events.json`.

## Pharmacy and Poisons Board
Home has a PPB card and every PPB-listed CPD event carries a PPB CPD tag and note. Explore -> Filters has a "PPB CPD events only" switch.
