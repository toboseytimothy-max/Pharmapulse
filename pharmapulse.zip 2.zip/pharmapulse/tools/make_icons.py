from PIL import Image, ImageDraw, ImageFilter
import math
N=1024
def bg():
    im=Image.new('RGB',(N,N)); px=im.load()
    a=(66,43,28); b=(29,18,11)
    for y in range(N):
        for x in range(N):
            d=math.hypot(x-N*0.3,y-N*0.2)/(N*1.1); t=min(1,d)
            px[x,y]=tuple(int(a[i]+(b[i]-a[i])*t) for i in range(3))
    return im.convert('RGBA')
def mark(im,k):
    c=N/2
    # seal rings
    R=Image.new('RGBA',(N,N),(0,0,0,0)); d=ImageDraw.Draw(R)
    for r,w,al in ((0.43,6,150),(0.395,3,90)):
        rr=N*r*k; d.ellipse((c-rr,c-rr,c+rr,c+rr),outline=(214,170,98,al),width=int(w*k+1))
    # tick marks around ring
    for i in range(48):
        a=i*2*math.pi/48; r1=N*0.43*k; r2=r1+N*(0.022 if i%4==0 else 0.012)*k
        d.line((c+r1*math.cos(a),c+r1*math.sin(a),c+r2*math.cos(a),c+r2*math.sin(a)),fill=(214,170,98,120),width=int(4*k+1))
    im.alpha_composite(R)
    # capsule
    w=N*0.5*k; h=N*0.2*k; r=h/2; x0=c-w/2; y0=c-h/2-N*0.06*k
    L=Image.new('RGBA',(N,N),(0,0,0,0)); ld=ImageDraw.Draw(L)
    sh=Image.new('RGBA',(N,N),(0,0,0,0)); ImageDraw.Draw(sh).rounded_rectangle((x0,y0+N*0.02,x0+w,y0+h+N*0.02),r,fill=(0,0,0,150))
    ld.rounded_rectangle((x0,y0,x0+w,y0+h),r,fill=(245,232,205,255))
    right=Image.new('RGBA',(N,N),(0,0,0,0)); ImageDraw.Draw(right).rounded_rectangle((x0,y0,x0+w,y0+h),r,fill=(184,92,44,255))
    m=Image.new('L',(N,N),0); ImageDraw.Draw(m).rectangle((c,0,N,N),fill=255); L.paste(right,(0,0),m)
    H=Image.new('RGBA',(N,N),(0,0,0,0)); ImageDraw.Draw(H).rounded_rectangle((x0+w*0.07,y0+h*0.14,x0+w*0.9,y0+h*0.27),h*0.07,fill=(255,255,255,85))
    cm=Image.new('L',(N,N),0); ImageDraw.Draw(cm).rounded_rectangle((x0,y0,x0+w,y0+h),r,fill=255)
    L=Image.alpha_composite(L,Image.composite(H,Image.new('RGBA',(N,N),(0,0,0,0)),cm))
    ang=-32; sh=sh.rotate(ang,resample=Image.BICUBIC,center=(c,c)).filter(ImageFilter.GaussianBlur(N*0.012)); L=L.rotate(ang,resample=Image.BICUBIC,center=(c,c))
    im.alpha_composite(sh); im.alpha_composite(L)
    # pulse
    ys=c+N*0.2*k; s=N*k
    pts=[(c-.30*s,ys),(c-.12*s,ys),(c-.06*s,ys-.08*s),(c,ys+.09*s),(c+.07*s,ys-.15*s),(c+.13*s,ys),(c+.30*s,ys)]
    lw=int(N*0.026*k)
    G=Image.new('RGBA',(N,N),(0,0,0,0)); ImageDraw.Draw(G).line(pts,fill=(230,181,102,190),width=lw*3,joint='curve'); G=G.filter(ImageFilter.GaussianBlur(N*0.014)); im.alpha_composite(G)
    P=Image.new('RGBA',(N,N),(0,0,0,0)); p=ImageDraw.Draw(P); p.line(pts,fill=(240,200,130,255),width=lw,joint='curve')
    for q in (pts[0],pts[-1]): p.ellipse((q[0]-lw/2,q[1]-lw/2,q[0]+lw/2,q[1]+lw/2),fill=(240,200,130,255))
    im.alpha_composite(P); return im
def rounded(im,rad):
    mk=Image.new('L',im.size,0); ImageDraw.Draw(mk).rounded_rectangle((0,0,N-1,N-1),rad,fill=255)
    o=Image.new('RGBA',im.size,(0,0,0,0)); o.paste(im,(0,0),mk); return o
a=rounded(mark(bg(),1.0),int(N*0.225)); m=mark(bg(),0.78).convert('RGB')
for n,sz in (('icon-512',512),('icon-192',192),('apple-touch-icon',180),('favicon-64',64)): a.resize((sz,sz),Image.LANCZOS).save(f'icons/{n}.png')
m.resize((512,512),Image.LANCZOS).save('icons/icon-maskable-512.png')
b=Image.new('RGBA',(96,96),(0,0,0,0)); d=ImageDraw.Draw(b); d.ellipse((8,8,88,88),fill=(255,255,255,255)); b.save('icons/badge-96.png')
