import json, re
Y='2026'
def d(s):
    # 'D Mon YYYY' -> ISO
    m={'Jan':1,'Feb':2,'Mar':3,'Apr':4,'May':5,'Jun':6,'Jul':7,'Aug':8,'Sep':9,'Oct':10,'Nov':11,'Dec':12}
    a,b,c=s.split(); return f"{int(c):04d}-{m[b]:02d}-{int(a):02d}"
E=[]
def add(title,org,cats,start,end=None,region='International',fmt='In-person',loc='',status='confirmed',url='',why='',prio=None,note='',fee=''):
    E.append(dict(id=re.sub(r'[^a-z0-9]+','-',(org+'-'+title).lower()).strip('-')[:70]+'-'+(start or 'tbc'),
      title=title,org=org,cats=cats,start=start,end=end or start,region=region,format=fmt,location=loc,
      status=status,url=url,why=why,priority=prio,note=note,fee=fee))
K='Kenya'
# --- Kenya
add('9th Kenya International Cancer Conference','Daktari Online / KESHO',['onc','conf','cr'],'2026-11-19','2026-11-22',K,'In-person','Sarova Whitesands, Mombasa',url='https://confluence.daktarionline.co.ke/app.daktarionline.africa/public/index.php/events',why='Oncology pharmacy, cancer medicines, clinical research, pharmaceutical care and cancer policy.',prio=10)
add("Annual Early Career Health Researchers' Symposium",'Aga Khan University',['cr','conf','career'],'2026-11-20','2026-11-21',K,'In-person','Trademark Hotel, Village Market, Nairobi',url='https://www.aku.edu/events/aechrs/Pages/home.aspx',why='Research careers, clinical trials, evidence-based medicine, health innovation and networking.',prio=5,fee='KSh 5,000 final-call fee; registration closes 18 Nov')
add('28th Commonwealth Medical Association Conference','Kenya Medical Association',['conf','ph'],'2026-11-12','2026-11-14',K,'In-person','Nairobi',url='https://www.kma.co.ke/kma-events/28th-cma',why='Theme: Building resilient health systems. AMR, pandemic preparedness, One Health, workforce.')
add('Kenya Public Health International Conference (KEPHIC)','Ministry of Health Kenya',['ph','conf'],None,None,K,'In-person','KICC, Nairobi',status='rescheduled',url='https://kephic.publichealth.go.ke/',why='Pharmaceutical policy, public health, medicine access, health systems. Moved from 27-29 Oct 2026 to Feb 2027; exact dates not yet announced.',note='Rescheduled to February 2027')
# --- Africa
add('5th International Conference on Public Health in Africa (CPHIA 2026)','Africa CDC',['ph','conf'],'2026-11-23','2026-11-27','Africa','In-person','Addis Ababa, Ethiopia',url='https://africacdc.org/events/cphia-2026/',why='Medicines access, African pharmaceutical manufacturing, health security and research.',prio=6)
# --- FIP
fip='https://www.fip.org/events'
add('Empowering pharmacists to support people living with psoriasis','FIP',['cpd','webinar'],'2026-11-05',None,'Online','Online',url=fip,why='Free/low-cost international pharmacy CPD, attendable from Kenya.')
add('5th JoPPP IMPACT Mongolia','FIP',['conf'],'2026-11-11','2026-11-13','International','In-person','Mongolia',url=fip,why='Pharmacy practice and policy collaboration.')
add('Interprofessional education and training','FIP',['cpd','webinar'],'2026-11-19',None,'Online','Online',url=fip,why='Interprofessional education for pharmacists.')
add('Mental health and person-centred pharmacy','FIP',['cpd','webinar','hosp'],'2026-11-23',None,'Online','Online',url=fip,why='Pharmacist role in mental health care.')
add('Pride and Progress in Pharmacy Conference','FIP',['conf'],'2027-02-04','2027-02-06','International','In-person','International (venue per FIP)',url=fip)
add('IDF World Diabetes Congress','IDF',['conf','hosp'],'2027-04-09','2027-04-12','International','In-person','Singapore',url='https://www.fip.org/events',why='Diabetes care, pharmacist-led interventions.')
add('85th FIP World Congress of Pharmacy','FIP',['conf','expo'],'2027-09-12','2027-09-15','International','In-person','International (venue per FIP)',url=fip,why='The flagship global pharmacy gathering.')
# --- ISPE
isp='https://my.ispe.org/ISPE/ispe/events/events_list.aspx'
for t,s,e,f,l in [
('CAPA / RCA / Investigations','2026-11-09',None,'In-person','Training'),
('Sterile Pharmaceutical Manufacturing Facility','2026-11-09',None,'In-person','Training'),
('Storage, Delivery and Qualification of Pharmaceutical Water','2026-11-09',None,'Online','Online'),
('Commissioning and Qualification','2026-11-16',None,'Online','Online'),
('Hands-On C&Q/PV/ATMP','2026-11-17',None,'In-person','Training'),
('Aseptic Processing & Annex 1','2026-11-19',None,'Online','Online'),
('Biopharmaceuticals: C&GT and ATMP','2026-11-23',None,'Online','Online'),
('Biopharmaceuticals: CMC Aspects','2026-11-30',None,'Online','Online'),
('GAMP Basic Principles with AI/ML','2026-12-01',None,'In-person','Training'),
('GAMP Data Integrity, 21 CFR Part 11','2026-12-07',None,'Online','Online'),
('Pharmaceutical Water Systems','2026-12-07',None,'Online','Online'),
('GAMP Basic Principles','2026-12-08',None,'In-person','Berlin'),
('Pharma 4.0 and Biopharma Conference','2026-12-10',None,'In-person','Berlin'),
('ATMP Manufacturing','2026-12-14',None,'Online','Online'),
('Facilities of the Future Conference','2027-02-01',None,'In-person','Long Beach, USA'),
('Aseptic Conference','2027-03-09',None,'In-person','Arlington, USA'),
('FDA-ISPE Compounding Quality Conference','2027-03-11',None,'In-person','Arlington, USA'),
('ISPE Europe Annual Conference','2027-04-26',None,'In-person','Prague'),
('ISPE APAC Annual Conference','2027-06-03',None,'In-person','Incheon')]:
    add(t,'ISPE',['gmp'],s,e,'Online' if f=='Online' else 'International',f,l,url=isp,why='GMP, quality and pharmaceutical engineering.' ,prio=8 if t.startswith('CAPA') else None)
# --- PPB CPD
ppb='https://products.pharmacyboardkenya.org/ppb_admin/pages/public_view_cpd_events.php'
for s,e,p,t,cats,pr in [
('2026-11-23',None,'International Cancer Institute','Clinical Trial Phases and Designs',['cpd','cr','onc'],None),
('2026-11-24',None,'International Cancer Institute','Cancer Treatment Basics and Common Cancers',['cpd','onc'],None),
('2026-11-25','2026-12-02','Care Medical Professionals Association','HIV response and community health outreach',['cpd','ph'],None),
('2026-11-26',None,'International Cancer Institute','Virtual multidisciplinary tumour board',['cpd','onc'],None),
('2026-11-26','2026-12-31','Daktari Online','International Opportunities and Global Mobility',['cpd','career'],None),
('2026-11-27','2026-12-02','inSupply Health','Family-planning training for pharmacists (hybrid)',['cpd','hosp'],None),
('2026-11-30',None,'International Cancer Institute','Kenya Regulatory Framework for Clinical Trials',['cpd','cr','ra'],3),
('2026-11-30',None,'International Cancer Institute','Virtual multidisciplinary tumour board',['cpd','onc'],None),
('2026-12-01',None,'International Cancer Institute','Clinician Navigator Programme: cancer care topics',['cpd','onc'],None),
('2026-12-03','2026-12-31','Daktari Online','Career Growth and Personal Branding for Healthcare Professionals',['cpd','career'],None)]:
    add(t,p+' (PPB CPD)',cats,s,e,K,'Hybrid' if 'hybrid' in t else 'Online/Check',  'See PPB register',url=ppb,why='Listed on the Pharmacy and Poisons Board CPD register. Confirm CPD points and delivery with the provider.',prio=pr,note='Some listings are single sessions within longer programmes.')
# --- PSK webinars (undated)
psk='https://psk.or.ke/webinars/'
for t in ['Introduction to Research Methods for Pharmacists','Enhancing Patient Outcomes in Type 2 Diabetes through Pharmacist-Led Interventions','Choosing the Right Non-systemic Treatment','Sensitisation on the KHPTRA Bill - Session 1','Sensitisation on the KHPTRA Bill - Session 2','Abstracts Presentation Guidelines','Sensitisation on PSK Membership Portal and CPD Events','Dissemination of Family Planning Guidelines']:
    add(t,'PSK',['webinar','cpd'],None,None,K,'Online','Online',status='tbc',url=psk,why='Advertised on the PSK webinar page; date not published. Confirm before registering.')
# --- RAPS
raps='https://www.raps.org/learn-develop/events.html'
for t,s,e,l,f in [
('Biologics CMC: Regulatory Challenges and Trends','2026-11-02','2026-11-03','Virtual','Online'),
('EU Medical Device Regulation Workshop','2026-11-02','2026-11-05','Virtual','Online'),
('Regulatory Intelligence Conference Europe','2026-11-03','2026-11-04','Barcelona','In-person'),
('AI in Regulatory Conference','2026-11-05','2026-11-06','Barcelona','In-person'),
('S6(R1) and animal-model safety webinar','2026-11-05',None,'Virtual','Online'),
('Regulatory Intelligence: From Alerts to Action','2026-11-09',None,'Virtual','Online'),
('ABHI UK HealthTech Conference','2026-11-09','2026-11-10','London','In-person'),
('Quality and Regulatory Summit','2026-11-12',None,'Foster City, USA','In-person'),
('Navigating AI Medical Device Regulations','2026-11-12',None,'Virtual','Online'),
('Global Regulatory Requirements to Compliant Local Action','2026-11-12',None,'Virtual','Online'),
('Combination Products Summit','2026-11-13',None,'Baltimore, USA','In-person'),
('Abuse Liability Assessment and Drug Development','2026-11-17',None,'Pittsburgh, USA','In-person'),
('Target Product Profile and Target Product Label','2026-11-18',None,'Wellesley, USA','In-person')]:
    add(t,'RAPS',['ra'],s,e,'Online' if f=='Online' else 'International',f,l,url=raps,why='Regulatory affairs career development.',prio=9 if t.startswith('Global Reg') else None)
# --- ISoP
add('10th ISoP Seminar: Intelligent Automation in Pharmacovigilance','ISoP',['pv','conf'],'2026-12-03','2026-12-04','International','In-person','Boston/Cambridge, USA',url='https://isoponline.org/training/seminar/isop-seminar-2026/',why='Ten years of PV intelligent automation: patient safety, technology, regulatory oversight.',prio=2)
# --- EMA
ema='https://www.ema.europa.eu/en/events/upcoming-events'
for t,s,e,l,f,c,p in [
('Committee for Orphan Medicinal Products','2026-11-03','2026-11-05','Amsterdam','In-person',['ra'],None),
('Committee for Medicinal Products for Veterinary Use','2026-11-03','2026-11-05','Amsterdam','In-person',['ra'],None),
('Committee for Advanced Therapies','2026-11-04','2026-11-06','Amsterdam','In-person',['ra'],None),
('Methodology Working Party meeting','2026-11-04',None,'Online','Online',['ra'],None),
('Paediatric Investigation Plans training','2026-11-05','2026-11-06','Amsterdam','In-person',['ra','cr'],None),
('European Network of Paediatric Research annual meeting','2026-11-05',None,'Online','Online',['cr'],None),
('SME Information Day: Innovation to Marketing Authorisation','2026-11-06',None,'Online','Online',['ra'],None),
('EudraVigilance ICH E2B(R3) reporting training','2026-11-09','2026-11-13','Online','Online',['pv','ra'],1),
('Committee for Medicinal Products for Human Use','2026-11-09','2026-11-12','Amsterdam','In-person',['ra'],None),
('Paediatric Committee meeting','2026-11-10','2026-11-13','Online','Online',['ra'],None)]:
    why='Individual case safety reporting and the E2B(R3) standard. Top pick for a PV career.' if p==1 else 'EMA official regulatory meeting/training.'
    add(t,'EMA',c,s,e,'Online' if f=='Online' else 'International',f,l,url=ema,why=why,prio=p)
# --- PDA
pda='https://www.pda.org/global-event-calendar'
for t,s,e,l in [
('Aseptic Processing of Biopharmaceuticals Conference','2026-11-03','2026-11-04','Incheon'),
('Contamination Control Strategy Workshop','2026-11-05',None,'Incheon'),
('Visual Inspection Workshop','2026-11-10',None,'Berlin'),
('Fundamentals of Aseptic Processing','2026-11-10','2026-11-11','Puerto Rico'),
('Pharmaceutical Elastomers and Aluminium Seals Training','2026-11-10','2026-11-11','Delaware, USA'),
('AI Revolution in Pharma Manufacturing Workshop','2026-11-11','2026-11-12','Berlin'),
('Mastering Automated Visual Inspection','2026-11-11','2026-11-12','Berlin'),
('Introduction to Visual Inspection','2026-11-11','2026-11-12','Berlin'),
('Environmental Monitoring Programme Training','2026-11-18','2026-11-19','Berlin'),
('Fundamentals of Aseptic Processing for ATMPs','2026-11-18','2026-11-19','Bethesda, USA'),
('Risk-Based Airflow Visualisation','2026-11-18','2026-11-20','Bethesda, USA'),
('GxP Auditing and Inspection Readiness','2026-11-19','2026-11-20','Bethesda, USA'),
('Annex 1 Implementation Workshop','2026-12-01','2026-12-02','Dublin'),
('Aseptic Processing Essentials','2026-12-01',None,'Bethesda, USA'),
('Quality Risk Management Training','2026-12-01',None,'Bethesda, USA'),
('Environmental Monitoring Training Certificate','2026-12-01','2026-12-03','California, USA'),
('Practical Quality Risk Assessment Tools','2026-12-02','2026-12-04','Bethesda, USA'),
('Site Visit at West Pharmaceutical Services','2026-12-03',None,'Ireland'),
('Aseptic Processing Certificate Programme','2026-12-07','2026-12-11','Bethesda, USA'),
('Isolator Systems: Design, Validation and Operation','2026-12-16','2026-12-17','Bethesda, USA'),
('Primary Container Bag Systems Workshop I','2027-01-28',None,'Paris'),
('Technology Transfer Projects in Pharma','2027-02-09','2027-02-10','Berlin'),
('Cell and Gene Pharmaceutical Products Conference','2027-02-16','2027-02-17','Tokyo'),
('Visual Inspection Training','2027-02-23','2027-02-24','Germany'),
('Single-Use Systems Training','2027-03-08','2027-03-10','Germany'),
('PDA Week','2027-03-14','2027-03-18','USA'),
('PDA Miniverse Conference','2027-03-15','2027-03-17','USA'),
('PDA Visual Inspection Forum','2027-03-15','2027-03-17','USA'),
('PDA Annual Meeting','2027-03-15','2027-03-17','USA'),
('Parenteral Packaging Conference','2027-04-20','2027-04-21','Munich'),
('World of Radiopharmaceuticals Workshop','2027-05-24',None,'Düsseldorf'),
('Good Aseptic Manufacturing Conference','2027-05-25','2027-05-26','Düsseldorf'),
('Manufacturing Excellence Conference','2027-06-01','2027-06-02','Cairo'),
('PDA Virus Conference','2027-06-21','2027-06-22','Florence'),
('Advanced Therapy Medicinal Products Conference','2027-06-23','2027-06-24','Florence')]:
    c=['gmp']+(['radio'] if 'Radio' in t else [])
    reg='Africa' if l=='Cairo' else 'International'
    add(t,'PDA',c,s,e,reg,'In-person',l,url=pda,why='Specialised radiopharmacy event.' if 'Radio' in t else 'Sterile manufacturing and pharmaceutical quality.',prio=7 if 'Radio' in t else None)
# --- WHO
who='https://www.who.int/news-room/events'
for t,s,e,f,why,c in [
('#MedSafetyWeek 2026','2026-11-02','2026-11-08','Online','Global medicines-safety campaign encouraging suspected side-effect reporting.',['pv','ph']),
('9th IGWG on the Pandemic Agreement','2026-11-02','2026-11-13','Hybrid','Pandemic preparedness and pharmaceutical access.',['ph']),
('Emergency Medical Teams Global Meeting','2026-11-03','2026-11-05','In-person','Emergency medicine and health systems.',['ph']),
('Market Access for Vaccines TAG','2026-11-04',None,'Online','Vaccine access and procurement.',['ph']),
('EPI-WIN webinar: arboviral disease clinical management','2026-11-04',None,'Online','Clinical treatment guidelines.',['webinar','ph']),
('WHO One Health webinar','2026-11-03',None,'Online','Public health and research.',['webinar','ph']),
('INSPIRE Lecture Series','2026-11-03','2026-11-12','Online','Health education and professional development.',['webinar']),
('SRHR signals of change public consultation','2026-11-03','2026-12-31','Online','Reproductive health policy consultation.',['ph'])]:
    add(t,'WHO',c,s,e,'Online' if f=='Online' else 'International',f,'Global',url=who,why=why)
# --- Parexel-listed industry events
px='https://www.parexel.com/about-us/events'
for t,s,e,l,c in [
('CNS Summit 2026','2026-11-01','2026-11-04','Boston',['cr']),
('ACR Convergence 2026','2026-11-06','2026-11-11','Orlando',['cr']),
('ISPOR Europe 2026','2026-11-08','2026-11-11','Vienna',['conf','cr']),
('BIO-Europe 2026','2026-11-09','2026-11-11','Cologne',['conf','expo']),
('FT Global Pharma and Biotech Summit','2026-11-10','2026-11-11','London',['conf']),
('Obesity Week 2026','2026-11-14','2026-11-17','Washington DC',['conf']),
('DIA India Annual Meeting','2026-11-18','2026-11-19','Navi Mumbai',['conf','cr','ra'])]:
    add(t,'Parexel (participating)',c,s,e,'International','In-person',l,url=px,why='Industry event listed on Parexel calendar (not organised by Parexel).')
# --- Novartis investor events
nv='https://www.novartis.com/events'
for t,s,l,f in [('ZKB Swiss Equity Conference','2026-11-05','Zurich','In-person'),('Guggenheim Healthcare Innovation Conference','2026-11-10','Boston','In-person'),('UBS European Conference','2026-11-10','London','In-person'),('Jefferies Global Healthcare Conference','2026-11-18','London','In-person'),('Meet Novartis Management','2026-11-19','London','In-person'),('Berenberg CFO Call Series','2026-11-25','Online','Online'),('Citi Global Healthcare Conference','2026-12-01','Miami','In-person'),('Bank of America R&D Call Series','2026-12-07','Online','Online'),('Deutsche Bank C-Suite Call Series','2026-12-09','Online','Online'),('J.P. Morgan Healthcare Conference','2027-01-11','San Francisco','In-person'),('Novartis 2026 Financial Results','2027-02-03','Basel','Online'),('Novartis Annual General Meeting','2027-03-05','Basel','In-person')]:
    add(t,'Novartis (investor)',['conf'],s,None,'Online' if f=='Online' else 'International',f,l,url=nv,why='Corporate/investor event: industry insight, not pharmacist CPD.')
# --- Fixed-date observances (annual, well-known dates)
obs=[('World Antimicrobial Resistance Awareness Week','2026-11-18','2026-11-24','WHO','https://www.who.int/campaigns/world-amr-awareness-week/world-amr-awareness-week-2026',['ph','hosp'],'Annual AMR stewardship campaign.'),
('World Diabetes Day','2026-11-14',None,'IDF','https://idf.org',['ph','hosp'],'Annual 14 Nov.'),
('World AIDS Day','2026-12-01',None,'UNAIDS / WHO','https://www.who.int',['ph'],'Annual 1 Dec.'),
('International Universal Health Coverage Day','2026-12-12',None,'WHO / UN','https://www.who.int',['ph'],'Annual 12 Dec.'),
('World Cancer Day','2027-02-04',None,'UICC','https://www.worldcancerday.org',['onc','ph'],'Annual 4 Feb.'),
('World TB Day','2027-03-24',None,'WHO','https://www.who.int',['ph'],'Annual 24 Mar.'),
('World Health Day','2027-04-07',None,'WHO','https://www.who.int',['ph'],'Annual 7 Apr.'),
('World Malaria Day','2027-04-25',None,'WHO','https://www.who.int',['ph'],'Annual 25 Apr.'),
('World Patient Safety Day','2027-09-17',None,'WHO','https://www.who.int',['pv','ph','hosp'],'Annual 17 Sep.'),
('World Pharmacists Day','2027-09-25',None,'FIP','https://www.fip.org',['conf'],'Annual 25 Sep.')]
for t,s,e,o,u,c,w in obs:
    add(t,o,c,s,e,'Online','Awareness day','Global',status='observance',url=u,why=w)
# --- Flagship with no verified dates
add('DIA 2027 Global Annual Meeting','DIA',['conf','ra','cr','pv'],None,None,'International','In-person','See DIA',status='tbc',url='https://www.diaglobal.org/Flagship/DIA-2027',why='Dates not verified by this app build. Check the official page.')
json.dump({'version':1,'generated':'2026-11-03','source_note':'Compiled from official calendars checked 3 Nov 2026. Undated items are marked tbc.','events':E},open('events.json','w'),ensure_ascii=False,indent=1)
print(len(E),'events')
