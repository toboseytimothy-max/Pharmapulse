const V='pharmapulse-v3';
const SHELL=['./','index.html','styles.css','app.js','manifest.webmanifest','events.json','icons/icon-192.png','icons/icon-512.png','icons/badge-96.png','icons/apple-touch-icon.png','fonts/lora.woff','fonts/lora-italic.woff','fonts/poppins-400.woff','fonts/poppins-500.woff','fonts/poppins-700.woff'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V&&x!=='pp-meta').map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);if(u.origin!==location.origin)return;
 if(u.pathname.endsWith('events.json')){e.respondWith(fetch(r).then(res=>{const cp=res.clone();caches.open(V).then(c=>c.put('events.json',cp));return res}).catch(()=>caches.match('events.json')));return}
 e.respondWith(caches.match(r,{ignoreSearch:true}).then(hit=>{const net=fetch(r).then(res=>{if(res.ok)caches.open(V).then(c=>c.put(r,res.clone()));return res}).catch(()=>hit);return hit||net}))});
const sig=e=>[e.title,e.start,e.end,e.status,e.location].join('|');
const pd=iso=>{const[y,m,d]=iso.split('-').map(Number);return new Date(y,m-1,d)};
async function bgCheck(){
 const mc=await caches.open('pp-meta');const mr=await mc.match('/__pp_meta');if(!mr)return;const M=await mr.json();
 let list;try{const base=M.feed||new URL('events.json',self.registration.scope).href;const r=await fetch(base+(base.includes('?')?'&':'?')+'_='+Date.now(),{cache:'no-store'});const j=await r.json();list=(Array.isArray(j)?j:j.events||[]).filter(e=>e&&e.id&&e.title)}catch(e){return}
 if(!list.length)return;
 const match=e=>(!M.interests.length||(e.cats||[]).some(c=>M.interests.includes(c)))&&(!M.regions.length||M.regions.includes(e.region));
 const added=[],changed=[];list.forEach(e=>{const s=sig(e);if(!(e.id in M.known)){if(Object.keys(M.known).length)added.push(e)}else if(M.known[e.id]!==s)changed.push(e);M.known[e.id]=s});
 const o={icon:'icons/icon-192.png',badge:'icons/badge-96.png',data:{url:'./?view=alerts'},vibrate:[80,40,80]};
 const mine=added.filter(match);
 if(M.notifyNew&&mine.length)await self.registration.showNotification(mine.length===1?'New event: '+mine[0].title:mine.length+' new events on PharmaPulse',{...o,body:mine.slice(0,3).map(e=>e.title).join(' · '),tag:'new-events'});
 const ch=changed.filter(e=>M.saved.includes(e.id));
 if(M.notifyNew&&ch.length)await self.registration.showNotification('Saved event updated: '+ch[0].title,{...o,body:ch.length>1?ch.length+' saved events changed':'Check the new details',tag:'updated-events'});
 if(M.remind){const n=Date.now();for(const e of list){if(!M.saved.includes(e.id)||!e.start)continue;const t=pd(e.start).getTime()+8*36e5;for(const l of M.leads){const k=e.id+'|'+l;if(n>=t-l*6e4&&n<t&&!M.reminded[k]){M.reminded[k]=n;await self.registration.showNotification((l>=1440?'Coming up: ':'Starting soon: ')+e.title,{...o,body:e.location||e.region,tag:'rem-'+k})}}}}
 await mc.put('/__pp_meta',new Response(JSON.stringify(M)));
 const c=await caches.open(V);c.put('events.json',new Response(JSON.stringify({events:list,generated:new Date().toISOString().slice(0,10)}),{headers:{'content-type':'application/json'}}));
}
self.addEventListener('periodicsync',e=>{if(e.tag==='pp-sync')e.waitUntil(bgCheck())});
self.addEventListener('notificationclick',e=>{e.notification.close();const u=e.notification.data?.url||'./';e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{for(const c of cs){if('focus' in c){c.navigate?.(u);return c.focus()}}return self.clients.openWindow(u)}))});
self.addEventListener('message',e=>{if(e.data==='SKIP_WAITING')self.skipWaiting()});
